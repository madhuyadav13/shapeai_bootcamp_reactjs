import React from "react";

function Info1() {
  return (
    <div className="note">
      <h1> vada pav </h1>
      <p> Rs.15 </p>
    </div>
  );
}

export default Info1;
