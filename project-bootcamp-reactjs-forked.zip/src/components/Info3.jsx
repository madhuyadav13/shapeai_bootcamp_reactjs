import React from "react";

function Info3() {
  return (
    <div className="note">
      <h1> chola bhature </h1>
      <p> Rs.75 </p>
    </div>
  );
}

export default Info3;
