import React from "react";

function Info() {
  return (
    <div className="note">
      <h1> pani puri </h1>
      <p> Rs.25 </p>
    </div>
  );
}

export default Info;
