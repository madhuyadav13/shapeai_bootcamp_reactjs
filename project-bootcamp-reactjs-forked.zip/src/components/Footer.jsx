import React from "react";

function Footer() {
  return (
    <div>
      <footer>
        <p>Copyrights by madhu's chat @ {new Date().getFullYear()} </p>
      </footer>
    </div>
  );
}
export default Footer;
