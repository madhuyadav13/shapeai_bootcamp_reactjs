import React from "react";

function Info2() {
  return (
    <div className="note">
      <h1> pavbhaji </h1>
      <p> Rs.40 </p>
    </div>
  );
}

export default Info2;
